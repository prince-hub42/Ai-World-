
async function solveHomework() {
  const question = document.getElementById('question').value;
  const answerDiv = document.getElementById('answer');
  answerDiv.innerHTML = "Solving...";
  try {
    const res = await fetch('/api/solve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question })
    });
    const data = await res.json();
    answerDiv.innerHTML = data.answer;
  } catch (e) {
    answerDiv.innerHTML = "Error: " + e.message;
  }
}
